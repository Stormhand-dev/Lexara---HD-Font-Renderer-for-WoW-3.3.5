## Installation

**Requirements:** World of Warcraft 3.3.5 (build 12340)

1. Download and extract `Lexara.zip` from [Releases](../../releases)
2. Copy `dinput8.dll` to your WoW root folder (where `WoW.exe` is located)
3. Launch the game

That's it. No addon, no configuration file, no additional steps.

---

**Compatibility**

Lexara coexists with ReShade and other DLL-based mods. If `dinput8.dll` 
is already taken by another mod, rename Lexara to `version.dll` or 
`dsound.dll` — all three names work identically.

---

**Uninstall**

Delete `dinput8.dll` and `skia.dll` from the WoW root folder.



---

**Files included**
- `dinput8.dll` — Lexara font renderer
- `skia.dll` — required graphics dependency